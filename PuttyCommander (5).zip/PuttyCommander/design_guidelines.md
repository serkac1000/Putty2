# PuTTY Script Generator - Design Guidelines

## Design Approach

**System Selected:** Material Design with developer-tool sensibility
**Justification:** This is a utility-focused productivity tool for IT professionals. Prioritize clarity, efficiency, and professional aesthetics over visual flair. Users need quick access to forms, clear code output, and reliable functionality.

## Core Design Elements

### A. Color Palette

**Dark Mode (Primary):**
- Background: 220 15% 12%
- Surface: 220 15% 16%
- Border: 220 10% 25%
- Primary Action: 210 100% 55%
- Success: 142 76% 45%
- Danger: 0 84% 60%
- Text Primary: 0 0% 95%
- Text Secondary: 0 0% 70%

**Light Mode:**
- Background: 0 0% 98%
- Surface: 0 0% 100%
- Border: 220 10% 85%
- Primary Action: 210 100% 50%
- Success: 142 71% 40%
- Danger: 0 72% 55%
- Text Primary: 220 20% 10%
- Text Secondary: 220 10% 45%

### B. Typography

- **Font Family:** 'Inter' for UI, 'JetBrains Mono' for code/script display
- **Headings:** Font weight 600, sizes: H1 (2rem), H2 (1.5rem), H3 (1.25rem)
- **Body:** Font weight 400, 0.875rem - 1rem
- **Code/Output:** Font weight 400, 0.875rem, monospace
- **Labels:** Font weight 500, 0.875rem, uppercase tracking

### C. Layout System

**Spacing Units:** Use Tailwind primitives 2, 4, 6, 8, 12, 16 (p-4, m-8, gap-6, etc.)
- Form spacing: gap-6 between sections, gap-4 within sections
- Card padding: p-6 to p-8
- Section margins: mb-8 to mb-12
- Container: max-w-6xl mx-auto px-4

### D. Component Library

**Navigation/Header:**
- Fixed top bar with subtle shadow, h-16
- Left: Logo + "PuTTY Script Generator" title
- Right: Theme toggle, save settings button
- Subtle background blur effect

**Form Components:**
- Text inputs: Rounded borders (rounded-md), focus ring in primary color, h-10
- Multi-line textarea: min-h-32, scrollable with custom scrollbar styling
- File upload: Dashed border dropzone with icon, hover state shows primary border
- Labels: Above inputs, required asterisks in danger color
- Help text: Below inputs in secondary text color

**Buttons:**
- Primary: Solid primary color, white text, rounded-md, px-6 py-2.5, font-medium
- Secondary: Outlined with border-2, transparent bg, hover fills with subtle primary
- Danger: Solid danger color for destructive actions
- Icon buttons: Square p-2, hover bg surface color

**Cards/Sections:**
- White/surface background with subtle border
- rounded-lg with shadow-sm
- Organized in 2-column grid on desktop (grid-cols-1 lg:grid-cols-2), single column mobile
- Section headers with bottom border separator

**Code Display:**
- Dark background within card (nested surface)
- Syntax highlighting optional but clean monospace essential
- Copy button positioned top-right
- Line numbers for generated script
- Scrollable with max-height constraint

**Output/Results:**
- Dedicated section for generated script with prominent display
- Download buttons for .bat and commands.txt positioned clearly
- Success/error messages with appropriate color-coded alerts

### E. Layout Structure

**Main Container:**
- Single-page application with vertical sections
- No hero image (utility tool - get straight to function)
- Clean header → Form sections → Output section flow

**Section Organization:**
1. **Credentials Section** (left column): Username, Password inputs with save functionality
2. **IP Addresses Section** (right column): Text input OR file upload with clear separator
3. **Commands Section** (full width): Large textarea for multi-line command entry
4. **Actions Bar** (full width): Generate Script, Save Settings, Clear buttons aligned right
5. **Generated Output** (full width): Collapsible/expandable script display with download options
6. **Instructions Panel** (right sidebar or collapsible): Prerequisites, how-to-use steps

**Responsive Behavior:**
- Desktop (lg+): 2-column grid for credentials/IP sections
- Tablet (md): Single column with maintained section order
- Mobile: Fully stacked, full-width inputs, sticky header

### F. Interaction Patterns

- Auto-save to localStorage on blur for all form fields
- Loading spinner during script generation
- Success toast notification when settings saved
- Confirmation dialog before clearing all data
- Inline validation for required fields
- Smooth accordion expansion for instructions panel

### G. Accessibility

- WCAG AA contrast ratios maintained
- Focus indicators on all interactive elements (2px offset ring)
- Keyboard navigation for all functions
- ARIA labels for icon-only buttons
- Error states clearly announced
- Screen reader friendly form structure

## Critical Implementation Notes

- Prioritize form clarity and code readability over decorative elements
- Maintain consistent dark mode across all inputs and code displays
- Use generous padding in form sections for breathing room
- Keep instructions accessible but not overwhelming (collapsible sidebar)
- Script output should be immediately actionable with download buttons
- Professional, trustworthy aesthetic appropriate for IT professionals