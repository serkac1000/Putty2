import type { PuttySettings, ScriptOutput } from "@shared/schema";

export function generateScript(settings: PuttySettings): ScriptOutput {
  const { username, password, ipAddresses, commands } = settings;
  
  const ips = parseIPAddresses(ipAddresses);
  const commandLines = commands.trim().split('\n').filter(line => line.trim());
  
  const commandsText = commandLines.join('\n');
  
  const outputFolder = 'C:\\Users\\HOT\\Documents\\putty-script-generator\\output';
  
  const batchScript = `@echo off
setlocal enabledelayedexpansion

echo ========================================
echo PuTTY Script Generator - Batch Execution
echo ========================================
echo.
echo Starting execution on %date% at %time%
echo Total devices: ${ips.length}
echo Output folder: ${outputFolder}
echo.

rem Create output directory if it doesn't exist
if not exist "${outputFolder}" mkdir "${outputFolder}"

rem Create or clear the results file
echo Device,Status,Timestamp > "${outputFolder}\\results.csv"

rem Create or clear the log file
echo Execution started at %date% %time% > "${outputFolder}\\run_log.txt"
echo. >> "${outputFolder}\\run_log.txt"

${ips.map((ip, index) => `
rem Processing device ${index + 1}/${ips.length}: ${ip}
echo.
echo [%time%] Processing ${ip}...
echo [%time%] Processing ${ip}... >> run_log.txt

plink.exe -ssh ${username}@${ip} -pw ${password} -batch -m commands.txt >> "${outputFolder}\\run_log.txt" 2>&1

if %errorlevel% equ 0 (
    echo ${ip},Success,%date% %time% >> "${outputFolder}\\results.csv"
    echo [SUCCESS] ${ip} completed successfully
    echo [SUCCESS] ${ip} completed successfully >> "${outputFolder}\\run_log.txt"
) else (
    echo ${ip},Failed,%date% %time% >> "${outputFolder}\\results.csv"
    echo [ERROR] ${ip} failed with error code %errorlevel%
    echo [ERROR] ${ip} failed with error code %errorlevel% >> "${outputFolder}\\run_log.txt"
)
`).join('')}

echo.
echo ========================================
echo Execution completed at %date% %time%
echo ========================================
echo Results saved to: ${outputFolder}\\results.csv
echo Detailed log saved to: ${outputFolder}\\run_log.txt
echo.

pause
`;

  return {
    batchScript: batchScript.trim(),
    commandsText,
  };
}

export function parseIPAddresses(input: string): string[] {
  const ips = input
    .split(/[\n,;]/)
    .map(ip => ip.trim())
    .filter(ip => ip.length > 0);
  
  return Array.from(new Set(ips));
}

export function downloadFile(content: string, filename: string): void {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export async function readTextFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      resolve(text || "");
    };
    reader.onerror = () => reject(new Error("Failed to read file"));
    reader.readAsText(file);
  });
}
