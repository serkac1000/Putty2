import type { PuttySettings } from "@shared/schema";

const STORAGE_KEY = "putty-script-settings";

export function loadSettings(): PuttySettings {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.error("Failed to load settings:", error);
  }
  
  return {
    username: "",
    password: "",
    ipAddresses: "",
    commands: "",
  };
}

export function saveSettings(settings: PuttySettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch (error) {
    console.error("Failed to save settings:", error);
    throw new Error("Failed to save settings to browser storage");
  }
}

export function clearSettings(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (error) {
    console.error("Failed to clear settings:", error);
  }
}
