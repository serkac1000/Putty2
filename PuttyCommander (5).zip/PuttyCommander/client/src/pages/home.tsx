import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ThemeToggle } from "@/components/theme-toggle";
import {
  Download,
  Upload,
  Copy,
  Save,
  Trash2,
  Terminal,
  ChevronDown,
  ChevronUp,
  FileText,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";
import { loadSettings, saveSettings, clearSettings } from "@/lib/storage";
import { generateScript, downloadFile, readTextFile, parseIPAddresses } from "@/lib/script-generator";
import type { PuttySettings } from "@shared/schema";

export default function Home() {
  const [settings, setSettings] = useState<PuttySettings>(() => loadSettings());
  const [generatedScript, setGeneratedScript] = useState<string>("");
  const [commandsText, setCommandsText] = useState<string>("");
  const [csvResults, setCsvResults] = useState<string>("");
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [instructionsOpen, setInstructionsOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const csvInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    const stored = loadSettings();
    setSettings(stored);
  }, []);

  const handleSettingChange = (field: keyof PuttySettings, value: string) => {
    setSettings((prev) => {
      const updated = { ...prev, [field]: value };
      saveSettings(updated);
      return updated;
    });
  };

  const handleSaveSettings = () => {
    try {
      saveSettings(settings);
      toast({
        title: "Settings Saved",
        description: "Your credentials and commands have been saved to browser storage.",
      });
    } catch (error) {
      toast({
        title: "Save Failed",
        description: error instanceof Error ? error.message : "Failed to save settings",
        variant: "destructive",
      });
    }
  };

  const handleClearAll = () => {
    clearSettings();
    setSettings({
      username: "",
      password: "",
      ipAddresses: "",
      commands: "",
    });
    setGeneratedScript("");
    setCommandsText("");
    setShowClearDialog(false);
    toast({
      title: "Cleared",
      description: "All settings and generated scripts have been cleared.",
    });
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const content = await readTextFile(file);
      handleSettingChange("ipAddresses", content);
      toast({
        title: "File Loaded",
        description: `Loaded IP addresses from ${file.name}`,
      });
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Failed to read the file. Please ensure it's a valid text file.",
        variant: "destructive",
      });
    }

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleCsvUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const content = await readTextFile(file);
      setCsvResults(content);
      toast({
        title: "Results Loaded",
        description: `Loaded results from ${file.name}`,
      });
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Failed to read the CSV file.",
        variant: "destructive",
      });
    }

    if (csvInputRef.current) {
      csvInputRef.current.value = "";
    }
  };

  const handleGenerateScript = () => {
    if (!settings.username || !settings.password || !settings.ipAddresses || !settings.commands) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields before generating the script.",
        variant: "destructive",
      });
      return;
    }

    const ips = parseIPAddresses(settings.ipAddresses);
    if (ips.length === 0) {
      toast({
        title: "No IP Addresses",
        description: "Please enter at least one valid IP address.",
        variant: "destructive",
      });
      return;
    }

    try {
      const output = generateScript(settings);
      setGeneratedScript(output.batchScript);
      setCommandsText(output.commandsText);
      toast({
        title: "Script Generated",
        description: `Successfully generated script for ${ips.length} device${ips.length > 1 ? 's' : ''}.`,
      });
    } catch (error) {
      toast({
        title: "Generation Failed",
        description: error instanceof Error ? error.message : "Failed to generate script",
        variant: "destructive",
      });
    }
  };

  const handleCopyScript = async () => {
    try {
      await navigator.clipboard.writeText(generatedScript);
      toast({
        title: "Copied",
        description: "Batch script copied to clipboard.",
      });
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy to clipboard.",
        variant: "destructive",
      });
    }
  };

  const handleDownloadBatch = () => {
    downloadFile(generatedScript, "run_plink.bat");
    toast({
      title: "Downloaded",
      description: "Batch script downloaded as run_plink.bat",
    });
  };

  const handleDownloadCommands = () => {
    downloadFile(commandsText, "commands.txt");
    toast({
      title: "Downloaded",
      description: "Commands file downloaded as commands.txt",
    });
  };

  const ipCount = parseIPAddresses(settings.ipAddresses).length;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <Terminal className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-semibold">PuTTY Script Generator</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="default"
                size="default"
                onClick={handleSaveSettings}
                data-testid="button-save-settings"
                className="gap-2"
              >
                <Save className="h-4 w-4" />
                <span className="hidden sm:inline">Save Settings</span>
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>SSH Credentials</CardTitle>
                <CardDescription>Enter your SSH authentication details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">
                    Username <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="username"
                    type="text"
                    placeholder="admin"
                    value={settings.username}
                    onChange={(e) => handleSettingChange("username", e.target.value)}
                    data-testid="input-username"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">
                    Password <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={settings.password}
                    onChange={(e) => handleSettingChange("password", e.target.value)}
                    data-testid="input-password"
                  />
                  <p className="text-sm text-muted-foreground">
                    Credentials are stored locally in your browser
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>IP Addresses</CardTitle>
                <CardDescription>
                  Enter IP addresses or upload a file
                  {ipCount > 0 && (
                    <span className="ml-2 text-primary font-medium">
                      ({ipCount} device{ipCount !== 1 ? 's' : ''})
                    </span>
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="ipAddresses">
                    IP Addresses <span className="text-destructive">*</span>
                  </Label>
                  <Textarea
                    id="ipAddresses"
                    placeholder="192.168.1.1&#10;192.168.1.2&#10;or comma-separated: 192.168.1.1, 192.168.1.2"
                    value={settings.ipAddresses}
                    onChange={(e) => handleSettingChange("ipAddresses", e.target.value)}
                    className="min-h-[120px] font-mono text-sm"
                    data-testid="input-ip-addresses"
                  />
                  <p className="text-sm text-muted-foreground">
                    One per line or comma/semicolon separated
                  </p>
                </div>
                <div className="relative">
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full gap-2"
                      data-testid="button-upload-file"
                    >
                      <Upload className="h-4 w-4" />
                      Upload IP List (.txt)
                    </Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".txt"
                      onChange={handleFileUpload}
                      className="hidden"
                      data-testid="input-file-upload"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Commands to Execute</CardTitle>
              <CardDescription>Enter the SSH commands to run on each device</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="commands">
                  Commands <span className="text-destructive">*</span>
                </Label>
                <Textarea
                  id="commands"
                  placeholder="show version&#10;show ip interface brief&#10;show running-config"
                  value={settings.commands}
                  onChange={(e) => handleSettingChange("commands", e.target.value)}
                  className="min-h-[200px] font-mono text-sm"
                  data-testid="input-commands"
                />
                <p className="text-sm text-muted-foreground">
                  Enter one command per line
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4">
            <Button
              variant="outline"
              onClick={() => setShowClearDialog(true)}
              className="gap-2 w-full sm:w-auto"
              data-testid="button-clear-all"
            >
              <Trash2 className="h-4 w-4" />
              Clear All
            </Button>
            <Button
              variant="default"
              size="lg"
              onClick={handleGenerateScript}
              className="gap-2 w-full sm:w-auto"
              data-testid="button-generate-script"
            >
              <Terminal className="h-4 w-4" />
              Generate Script
            </Button>
          </div>

          {generatedScript && (
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Generated Batch Script</CardTitle>
                    <CardDescription>
                      Copy or download the generated files
                    </CardDescription>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleCopyScript}
                      className="gap-2"
                      data-testid="button-copy-script"
                    >
                      <Copy className="h-4 w-4" />
                      Copy Script
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDownloadBatch}
                      className="gap-2"
                      data-testid="button-download-batch"
                    >
                      <Download className="h-4 w-4" />
                      Download .bat
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleDownloadCommands}
                      className="gap-2"
                      data-testid="button-download-commands"
                    >
                      <FileText className="h-4 w-4" />
                      Download commands.txt
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  <pre className="bg-muted/50 rounded-md p-4 overflow-x-auto max-h-[500px] text-sm font-mono">
                    <code data-testid="text-generated-script">{generatedScript}</code>
                  </pre>
                </div>
                <Alert className="mt-4">
                  <CheckCircle2 className="h-4 w-4" />
                  <AlertDescription>
                    Place both <code className="font-mono bg-muted px-1 py-0.5 rounded">run_plink.bat</code> and{" "}
                    <code className="font-mono bg-muted px-1 py-0.5 rounded">commands.txt</code> in the same directory as{" "}
                    <code className="font-mono bg-muted px-1 py-0.5 rounded">plink.exe</code>
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <CardTitle>Execution Results</CardTitle>
                  <CardDescription>
                    Upload and view the results.csv file generated after running the batch script
                  </CardDescription>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => csvInputRef.current?.click()}
                  className="gap-2"
                  data-testid="button-upload-csv"
                >
                  <Upload className="h-4 w-4" />
                  Upload results.csv
                </Button>
                <input
                  ref={csvInputRef}
                  type="file"
                  accept=".csv,.txt"
                  onChange={handleCsvUpload}
                  className="hidden"
                  data-testid="input-csv-upload"
                />
              </div>
            </CardHeader>
            <CardContent>
              {csvResults ? (
                <div className="space-y-4">
                  <div className="flex justify-end">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => downloadFile(csvResults, "results.csv")}
                      className="gap-2"
                    >
                      <Download className="h-4 w-4" />
                      Download Results
                    </Button>
                  </div>
                  <div className="relative">
                    <div className="bg-muted/50 rounded-md p-4 overflow-x-auto max-h-[400px]">
                      <table className="w-full text-sm">
                        <thead>
                          <tr className="border-b border-border">
                            {csvResults.split('\n')[0]?.split(',').map((header, i) => (
                              <th key={i} className="text-left p-2 font-semibold">
                                {header.trim()}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="font-mono">
                          {csvResults.split('\n').slice(1).filter(line => line.trim()).map((line, i) => (
                            <tr key={i} className="border-b border-border/50">
                              {line.split(',').map((cell, j) => (
                                <td key={j} className="p-2">
                                  {cell.trim()}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="space-y-2">
                    <p className="font-semibold">To view execution results:</p>
                    <ol className="list-decimal list-inside space-y-1 ml-2">
                      <li>Run the downloaded batch script on your Windows computer</li>
                      <li>Find <code className="font-mono bg-muted px-1 py-0.5 rounded">results.csv</code> in <code className="font-mono bg-muted px-1 py-0.5 rounded">C:\Users\HOT\Documents\putty-script-generator\output</code></li>
                      <li>Click "Upload results.csv" above to view the results here</li>
                    </ol>
                    <p className="text-xs text-muted-foreground mt-2">
                      Note: The CSV file is generated locally on your machine, not on this web server.
                    </p>
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          <Card>
            <Collapsible open={instructionsOpen} onOpenChange={setInstructionsOpen}>
              <CardHeader>
                <CollapsibleTrigger className="flex items-center justify-between w-full hover-elevate rounded-md p-2 -m-2" data-testid="button-toggle-instructions">
                  <CardTitle className="text-lg">Instructions & Prerequisites</CardTitle>
                  {instructionsOpen ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </CollapsibleTrigger>
              </CardHeader>
              <CollapsibleContent>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <AlertCircle className="h-4 w-4 text-primary" />
                      Prerequisites
                    </h3>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-6">
                      <li>PuTTY must be installed on your system</li>
                      <li>
                        The <code className="font-mono bg-muted px-1 py-0.5 rounded">plink.exe</code> executable must be in your system's PATH or in the same directory as the batch file
                      </li>
                      <li>You need SSH access credentials for the target devices</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <Terminal className="h-4 w-4 text-primary" />
                      How to Use
                    </h3>
                    <ol className="list-decimal list-inside space-y-2 text-sm text-muted-foreground ml-6">
                      <li>
                        <strong>Fill in the details:</strong>
                        <ul className="list-disc list-inside ml-6 mt-1 space-y-1">
                          <li>Enter your SSH username and password</li>
                          <li>Add IP addresses (one per line or comma-separated)</li>
                          <li>Or upload a .txt file with IP addresses</li>
                          <li>Enter the commands to execute on each device</li>
                        </ul>
                      </li>
                      <li className="mt-2">
                        <strong>Generate the script:</strong>
                        <ul className="list-disc list-inside ml-6 mt-1 space-y-1">
                          <li>Click the "Generate Script" button</li>
                          <li>The batch script and commands.txt will be generated</li>
                        </ul>
                      </li>
                      <li className="mt-2">
                        <strong>Download and run:</strong>
                        <ul className="list-disc list-inside ml-6 mt-1 space-y-1">
                          <li>Download both the .bat file and commands.txt</li>
                          <li>Place them in the same directory as plink.exe</li>
                          <li>Double-click the .bat file to execute</li>
                          <li>Results will be saved to results.csv</li>
                          <li>Execution log will be saved to run_log.txt</li>
                        </ul>
                      </li>
                    </ol>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-2">Features</h3>
                    <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-6">
                      <li>Settings are automatically saved to your browser</li>
                      <li>Click "Save Settings" to manually save anytime</li>
                      <li>Support for multiple IP addresses via text input or file upload</li>
                      <li>Execution results saved to CSV format</li>
                      <li>Detailed logging for troubleshooting</li>
                    </ul>
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>
        </div>
      </main>

      <footer className="border-t py-6 px-4 sm:px-6 lg:px-8 mt-12">
        <div className="max-w-7xl mx-auto text-center text-sm text-muted-foreground">
          <p>PuTTY Script Generator - Automate SSH commands across multiple devices</p>
        </div>
      </footer>

      <AlertDialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear All Settings?</AlertDialogTitle>
            <AlertDialogDescription>
              This will clear all saved credentials, IP addresses, commands, and generated scripts.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-clear">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleClearAll} data-testid="button-confirm-clear">
              Clear All
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
